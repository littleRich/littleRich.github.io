#### 关于StackNavigator、TabNavigator、DrawerNavigator三个同时使用注意事项： 
* 嵌套顺序为

DrawerNavigator -> StackNavigator -> TabNavigator
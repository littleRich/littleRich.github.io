package com.interactswithandroid;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;


/*
 * 项目名:    InteractsWithAndroid
 * 包名       com.interactswithandroid
 * 文件名:    DetailsActivity
 * 创建者:    ZSY
 * 创建时间:  2017/10/15 on 22:07
 * 描述:     TODO
 */
public class DetailsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details_activity);
    }
}

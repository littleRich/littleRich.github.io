### How to use ?

**点击这里[Wiki](https://github.com/azhon/ReactNative/wiki)**
### [CSDN博客专栏链接点我](http://blog.csdn.net/column/details/17709.html)
**由于在2017年10月11日 ReactNative将版本更新至了v0.49导致有些东西无法使用，所以这里提供了v0.48版本的[node_module](http://pan.baidu.com/s/1c2D7eiW)依赖库下载。**

**下载好后将node_module拷贝至项目根目录即可**

## 以下项目基于react-native v0.48版本

* QQLoginPage---效果图---[使用介绍](http://blog.csdn.net/a_zhon/article/details/78040711)

<img src="https://github.com/azhon/ReactNative/blob/master/effectImage/20170918162505881.png" width="300">

* LifeCycle---[使用介绍](http://blog.csdn.net/a_zhon/article/details/78113370)


* UseScrollView---效果图---[使用介绍](http://blog.csdn.net/a_zhon/article/details/78118091)

<img src="https://github.com/azhon/ReactNative/blob/master/effectImage/20170927170653819.gif" width="350">

* UseListView---效果图---[使用介绍](http://blog.csdn.net/a_zhon/article/details/78137936)

<img src="https://github.com/azhon/ReactNative/blob/master/images/listview.gif" width="350">

* Pagejump---效果图---[使用介绍](http://blog.csdn.net/a_zhon/article/details/78195498)

<img src="https://github.com/azhon/ReactNative/blob/master/effectImage/20171010165955532.gif" width="450">

---

## 以下项目基于react-native v0.49版本 [node_modules  v0.49.3.zip下载](http://pan.baidu.com/s/1qYC2KWG)

* TabNavigator---效果图---[使用介绍](http://blog.csdn.net/a_zhon/article/details/78228667)

<img src="https://github.com/azhon/ReactNative/blob/master/effectImage/20171013160758103.png" width="300" height="500">&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://github.com/azhon/ReactNative/blob/master/effectImage/20171013160907556.png" width="300" height="500">

* StackTabNavigator---效果图---将StackNavigator和TabNavigator结合使用的一个案例

<img src="https://github.com/azhon/ReactNative/blob/master/effectImage/20171014132434825.gif">&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://github.com/azhon/ReactNative/blob/master/effectImage/20171014135041556.gif">

* DrawerStackTabNavigator---效果图---将StackNavigator、DrawerNavigator和TabNavigator结合使用的一个案例

<img src="https://github.com/azhon/ReactNative/blob/master/effectImage/20171014191729436.png" width="600">

* InteractsWithAndroid---效果图---[使用介绍](http://blog.csdn.net/a_zhon/article/details/78255146)

<img src="https://github.com/azhon/ReactNative/blob/master/effectImage/20171016202912674.gif" width="300">

* UseFlatList---效果图---[使用介绍](http://blog.csdn.net/a_zhon/article/details/78365100)

 <img src="https://github.com/azhon/ReactNative/blob/master/effectImage/20171025170146617.gif" width="300">


